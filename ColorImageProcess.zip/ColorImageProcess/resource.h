﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// ColorImageProcess.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ColorImageProcessTYPE       130
#define IDD_Double_Input                310
#define IDD_DIALOG1                     312
#define IDC_EDIT1                       1000
#define IDC_EDIT_CONSTANT               1000
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_Equalmage                    32773
#define ID_EqualImage                   32774
#define ID_Menu                         32775
#define ID_GrayScale                    32776
#define ID_HSI32777                     32777
#define ID_H                            32778
#define ID_Change_Saturation            32779
#define ID_HSI32780                     32780
#define ID_HSI32781                     32781
#define ID_Change_Intencity             32782
#define ID_Change_Intensity             32783
#define ID_Change_                      32784
#define ID_Change_Hue                   32785
#define ID_Menu32786                    32786
#define ID_Add_Image                    32787
#define ID_32788                        32788
#define ID_Inverse_Image                32789
#define ID_32790                        32790
#define ID_Image_Gamma                  32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_32796                        32796
#define ID_32797                        32797
#define ID_32798                        32798
#define ID_32799                        32799
#define ID_32800                        32800
#define ID_Rotate_By_Degree             32801
#define ID_Zoom_In                      32802
#define ID_Zoom_Out                     32803
#define ID_32809                        32809
#define ID_Cyberucnk                    32810
#define ID_CyberPunk                    32811
#define ID_32812                        32812
#define ID_32813                        32813
#define ID_32814                        32814
#define ID_32815                        32815

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32816
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
